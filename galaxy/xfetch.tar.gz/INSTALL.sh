#!/bin/sh

cp xfetch.py xfetch
chmod +x xfetch
mv xfetch /usr/bin
