#!/bin/sh

cp xfetch.py xfetch
mv xfetch /usr/bin
