#!/bin/sh

rm /usr/bin/xfetch
cp xfetch.py xfetch
mv xfetch /usr/bin
