#!/bin/sh

rm /usr/bin/xfetch
cp xfetch.py xfetch
chmod +x xfetch
mv xfetch /usr/bin
