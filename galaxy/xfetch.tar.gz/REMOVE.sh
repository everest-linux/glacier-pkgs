#!/bin/sh

rm /usr/bin/xfetch
