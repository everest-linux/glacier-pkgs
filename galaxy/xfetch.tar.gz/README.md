xfetch is a simpler alternative to neofetch. Although not as visually appealing as neofetch, xinfo aims to provide a simple, easy to read system information output that is easily modifiable should the user know basic python. One notable advantage of xinfo is that, no matter what operating system you run, as long as it supports python, xinfo will just work.

**INSTALLATION**
- Clone this repository
- Run INSTALL.sh as root

**CUSTOMIZATION**
Edit /usr/bin/xfetch

**GET FEATURED**

Want to have your xfetch configuration featured on the README? Contact me through github
