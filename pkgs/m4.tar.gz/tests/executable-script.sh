printf 'Halle '
printf "Potta"
# This script is intentionally not immediately recognizable as a shell script.
# Don't add a #! header in the first line.
