#!/bin/sh

rm /bin/c++
rm /bin/cc
rm /bin/cpp
rm /bin/g++
rm /bin/gcc
rm /bin/gcc-ar
rm /bin/gcc-nm
rm /bin/gcc-ranlib
rm /bin/gcov
rm /bin/gcov-dump
rm /bin/gcov-tool
rm /bin/lto-dump
rm /usr/bin/c++
rm /usr/bin/cc
rm /usr/bin/cpp
rm /usr/bin/g++
rm /usr/bin/gcc
rm /usr/bin/gcc-ar
rm /usr/bin/gcc-nm
rm /usr/bin/gcc-ranlib
rm /usr/bin/gcov
rm /usr/bin/gcov-dump
rm /usr/bin/gcov-tool
rm /usr/bin/lto-dump
rm /lib/libasan.a
rm /lib/libasan.so
rm /lib/libatomic.a
rm /lib/libatomic.so
rm /lib/libcc1.so
rm /lib/libgcc.a
rm /lib/libgcc_eh.a
rm /lib/libgcc_s.so
rm /lib/libgcov.a
rm /lib/libgomp.a
rm /lib/libgomp.so
rm /lib/libitm.a
rm /lib/libitm.so
rm /lib/liblsan.a
rm /lib/liblsan.so
rm /lib/liblto_plugin.so
rm /lib/libquadmath.a
rm /lib/libquadmath.so
rm /lib/libssp.a
rm /lib/libssp.so
rm lib/libssp_nonshared.a
rm /lib/libstdc++.a
rm /lib/libstdc++.so
rm /lib/libstdc++fs.a
rm /lib/libtsan.a
rm /lib/libtsan.so
rm /lib/libubsan.a
rm /lib/libubsan.so
rm -rf /usr/include/c++
rm -rf /usr/lib/gcc
rm -rf /usr/libexec/gcc
rm -rf /usr/share/gcc-11.2
sed -e '/static.*SIGSTKSZ/d' \
    -e 's/return kAltStackSize/return SIGSTKSZ * 4/' \
    -i libsanitizer/sanitizer_common/sanitizer_posix_libcdep.cpp
case $(uname -m) in
  x86_64)
    sed -e '/m64=/s/lib64/lib/' \
        -i.orig gcc/config/i386/t-linux64
  ;;
esac
mkdir -v build
cd build
../configure --prefix=/usr            \
             LD=ld                    \
             --enable-languages=c,c++ \
             --disable-multilib       \
             --disable-bootstrap      \
             --with-system-zlib

make
ulimit -s 32768
chown -Rv tester .
su tester -c "PATH=$PATH make -k check"
../contrib/test_summary
make install
rm -rf /usr/lib/gcc/$(gcc -dumpmachine)/11.2.0/include-fixed/bits/
chown -v -R root:root \
    /usr/lib/gcc/*linux-gnu/11.2.0/include{,-fixed}
ln -svr /usr/bin/cpp /usr/lib
ln -sfv ../../libexec/gcc/$(gcc -dumpmachine)/11.2.0/liblto_plugin.so \
        /usr/lib/bfd-plugins/
echo 'int main(){}' > dummy.c
cc dummy.c -v -Wl,--verbose &> dummy.log
readelf -l a.out | grep ': /lib'
grep -o '/usr/lib.*/crt[1in].*succeeded' dummy.log
grep -B4 '^ /usr/include' dummy.log
grep 'SEARCH.*/usr/lib' dummy.log |sed 's|; |\n|g'
grep "/lib.*/libc.so.6 " dummy.log
grep found dummy.log
rm -v dummy.c a.out dummy.log
mkdir -pv /usr/share/gdb/auto-load/usr/lib
mv -v /usr/lib/*gdb.py /usr/share/gdb/auto-load/usr/lib

