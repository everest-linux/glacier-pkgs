#!/bin/sh

rm /bin/c++
rm /bin/cc
rm /bin/cpp
rm /bin/g++
rm /bin/gcc
rm /bin/gcc-ar
rm /bin/gcc-nm
rm /bin/gcc-ranlib
rm /bin/gcov
rm /bin/gcov-dump
rm /bin/gcov-tool
rm /bin/lto-dump
rm /usr/bin/c++
rm /usr/bin/cc
rm /usr/bin/cpp
rm /usr/bin/g++
rm /usr/bin/gcc
rm /usr/bin/gcc-ar
rm /usr/bin/gcc-nm
rm /usr/bin/gcc-ranlib
rm /usr/bin/gcov
rm /usr/bin/gcov-dump
rm /usr/bin/gcov-tool
rm /usr/bin/lto-dump
rm /lib/libasan.a
rm /lib/libasan.so
rm /lib/libatomic.a
rm /lib/libatomic.so
rm /lib/libcc1.so
rm /lib/libgcc.a
rm /lib/libgcc_eh.a
rm /lib/libgcc_s.so
rm /lib/libgcov.a
rm /lib/libgomp.a
rm /lib/libgomp.so
rm /lib/libitm.a
rm /lib/libitm.so
rm /lib/liblsan.a
rm /lib/liblsan.so
rm /lib/liblto_plugin.so
rm /lib/libquadmath.a
rm /lib/libquadmath.so
rm /lib/libssp.a
rm /lib/libssp.so
rm lib/libssp_nonshared.a
rm /lib/libstdc++.a
rm /lib/libstdc++.so
rm /lib/libstdc++fs.a
rm /lib/libtsan.a
rm /lib/libtsan.so
rm /lib/libubsan.a
rm /lib/libubsan.so
rm -rf /usr/include/c++
rm -rf /usr/lib/gcc
rm -rf /usr/libexec/gcc
rm -rf /usr/share/gcc-11.2

