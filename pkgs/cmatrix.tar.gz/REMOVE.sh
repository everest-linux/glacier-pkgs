#!/bin/sh

rm /usr/bin/cmatrix
