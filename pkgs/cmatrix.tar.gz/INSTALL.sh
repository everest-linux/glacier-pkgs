#!/bin/sh

mv cmatrix /usr/bin
