#!/bin/sh

mv sherpa /usr/bin
mv sherpa.desktop /usr/share/applications
