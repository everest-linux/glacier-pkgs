#!/bin/sh

rm /usr/bin/sherpa
rm /usr/share/applications/sherpa.desktop
