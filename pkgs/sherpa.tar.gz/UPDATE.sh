#!/bin/sh

rm /usr/bin/sherpa
rm /usr/share/applications/sherpa.desktop
mv sherpa /usr/bin/sherpa
mv sherpa.desktop /usr/share/applications
