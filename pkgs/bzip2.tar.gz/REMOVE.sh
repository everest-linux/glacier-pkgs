#!/bin/sh

rm /bin/bunzip2 /bin/bzcat /bin/bzcmp /bin/bzdiff /bin/bzegrep /bin/bzfgrep /bin/bzgrep /bin/bzip2 /bin/bzip2recover /bin/bzless /bin/bzmore
rm /lib/libbz2.so
rm -rf /usr/share/doc/bzip2-1.0.8
