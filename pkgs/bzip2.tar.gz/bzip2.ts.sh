#!/bin/sh

touch /var/log/glacier/bzip2.timestamp
date >> /var/log/glacier/bzip2.timestamp
