#!/bin/sh

rm /lib/libhistory.so /lib/libreadline.so
rm -rf /usr/include/readline /usr/share/doc/readline-8.1.2
