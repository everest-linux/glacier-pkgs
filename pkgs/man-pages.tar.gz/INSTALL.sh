#!/bin/sh
make prefix=/usr install
