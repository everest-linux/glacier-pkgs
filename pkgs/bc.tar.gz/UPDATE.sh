#!/bin/sh

rm /bin/bc
rm /bin/dc
CC=gcc ./configure --prefix=/usr -G -O3
make
make test
make install
