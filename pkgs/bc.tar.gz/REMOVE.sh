#!/bin/sh

rm /bin/bc
rm /bin/dc
