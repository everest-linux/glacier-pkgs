#!/bin/sh

touch /var/log/glacier/bc.timestamp
date >> /var/log/glacier/bc.timestamp
