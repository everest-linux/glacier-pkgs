#!/bin/sh

CC=gcc ./configure --prefix=/usr -G -O3
make
make test
make install
