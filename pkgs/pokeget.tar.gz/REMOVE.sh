#!/bin/sh

make uninstall PREFIX="/usr"