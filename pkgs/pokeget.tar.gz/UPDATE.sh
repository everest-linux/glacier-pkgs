#!/bin/sh

make uninstall PREFIX="/usr"
make install PREFIX="/usr"