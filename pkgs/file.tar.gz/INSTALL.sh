#!/bin/sh

./configure --prefix=/usr
make
make check
make install
