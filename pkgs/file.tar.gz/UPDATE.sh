#!/bin/sh

rm /bin/file
rm /lib/libmagic.so
./configure --prefix=/usr
make
make check
make install
