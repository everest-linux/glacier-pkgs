#!/bin/sh

rm /bin/file
rm /lib/libmagic.so
