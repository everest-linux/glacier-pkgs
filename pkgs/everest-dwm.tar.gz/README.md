# everest-dwm
This repository contains my personal build of dwm. Works best with the following programs:

- Sherpa (https://github.com/everest-linux/sherpa)
- Compton (https://github.com/chjj/compton)
- Feh (https://github.com/derf/feh)
- slstatus (https://tools.suckless.org/slstatus/)
