#!/bin/sh

rm /usr/bin/dwm
rm /usr/bin/slstatus
rm /usr/bin/dmenu
rm /usr/bin/compton
