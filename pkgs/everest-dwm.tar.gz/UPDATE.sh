#!/bin/sh

rm /usr/bin/dwm
rm /usr/bin/slstatus
rm /usr/bin/dmenu
rm /usr/bin/compton
echo "[ i ] Starting build of dwm..."
cd dwm-6.3
make
make install
echo "[ i ] Starting build of dmenu..."
cd ..
cd dmenu-5.1
make
make install
echo "[ i ] Starting build of slstatus..."
cd ..
cd slstatus
make
make install
echo "[ i ] Starting build of compton..."
cd ..
cd compton
make
make docs
make install
echo "[ ! ] The following file needs to be overwritten: .xinitrc"
echo "[ ! ] It is recommended to back up this file."
while true; do
    read -p "[ ? ] Would you like to continue?" yn
    case $yn in
        [Yy]* ) cd .. && rm ~/.xinitrc && cp xinitrc ~/.xinitrc; break;;
        [Nn]* ) exit;;
        * ) echo "[ ! ] You must answer either yes or no.";;
    esac
done

