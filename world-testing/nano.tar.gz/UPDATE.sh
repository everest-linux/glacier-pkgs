#!/bin/sh

rm /bin/nano
rm /bin/rnano
rm -rf /usr/share/nano /usr/share/doc/nano-6.3
./configure --prefix=/usr     \
            --sysconfdir=/etc \
            --enable-utf8     \
            --docdir=/usr/share/doc/nano-6.3 &&
make
make install &&
install -v -m644 doc/{nano.html,sample.nanorc} /usr/share/doc/nano-6.3
