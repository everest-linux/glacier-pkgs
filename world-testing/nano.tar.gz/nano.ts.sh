touch /var/log/glacier/nano.timestamp
date >> /var/log/glacier/nano.timestamp
