#!/bin/sh

rm /bin/lzcat /bin/lzcmp /bin/lzdiff /bin/lzegrep /bin/lzfgrep /bin/lzgrep /bin/lzless /bin/lzma /bin/lzmadec /bin/lzmainfo /bin/lzmore /bin/unlzma /bin/unxz /bin/xz /bin/xzcat /bin/xzcmp /bin/xzdec /bin/xzdiff /bin/xzegrep /bin/xzfgrep /bin/xzgrep /bin/xzless /bin/xzmore
rm /lib/liblzma.so
rm -rf /0usr/include/lzma
rm -rf /usr/share/doc/xz-5.2.5
