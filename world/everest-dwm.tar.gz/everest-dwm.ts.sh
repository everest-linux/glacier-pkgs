#!/bin/sh

touch /var/log/glacier/(package_name).timestamp
date >> /var/log/glacier/(package_name).timestamp
