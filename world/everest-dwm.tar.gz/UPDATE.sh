#!/bin/sh

rm /usr/bin/dwm
rm /usr/bin/slstatus
rm /usr/bin/dmenu
rm /usr/bin/compton
echo "[ i ] Starting build of dwm..."
cd dwm-6.3
make
make install
echo "[ i ] Starting build of dmenu..."
cd ..
cd dmenu-5.1
make
make install
echo "[ i ] Starting build of slstatus..."
cd ..
cd slstatus
make
make install
echo "[ i ] Starting build of compton..."
cd ..
cd compton
make
make docs
make install
echo "[ ! ] The following files need to be overwritten: ~/.xinitrc , /etc/X11/xinit/xinitrc"
echo "[ ! ] It is recommended to back up these files."
while true; do
    read -p "[ ? ] Would you like to continue?" yn
    case $yn in
        [Yy]* ) cd .. && rm ~/.xinitrc && cp xinitrc ~/.xinitrc && rm /etc/X11/xinit/xinitrc; break;;
        [Nn]* ) exit;;
        * ) echo "[ ! ] You must answer either yes or no.";;
    esac
done
