#!/bin/sh

rm /usr/bin/pfetch
mv pfetch /usr/bin
