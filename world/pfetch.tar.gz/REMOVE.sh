#!/bin/sh

rm /usr/bin/pfetch
