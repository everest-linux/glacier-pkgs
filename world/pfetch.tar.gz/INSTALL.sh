#!/bin/sh

mv pfetch /usr/bin
