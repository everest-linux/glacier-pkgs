#!/bin/sh

rm /lib/libz.so
