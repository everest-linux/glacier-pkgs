#!/bin/sh

rm /bin/flex /bin/flex++ /bin/lex
rm /lib/libfl.so
rm -rf /usr/share/doc/flex-2.6.4
./configure --prefix=/usr \
            --docdir=/usr/share/doc/flex-2.6.4 \
            --disable-static
make
make check
make install
ln -sv flex /usr/bin/lex
