#!/bin/sh

touch /var/log/glacier/flex.timestamp
date >> /var/log/glacier/flex.timestamp
