#!/bin/sh

rm /bin/flex /bin/flex++ /bin/lex
rm /lib/libfl.so
rm -rf /usr/share/doc/flex-2.6.4
