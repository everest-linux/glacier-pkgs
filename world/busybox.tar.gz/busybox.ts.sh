#!/bin/sh

touch /var/log/glacier/busybox.timestamp
date >> /var/log/glacier/busybox.timestamp
