#!/bin/sh

rm /usr/bin/cmatrix
mv cmatrix /usr/bin
