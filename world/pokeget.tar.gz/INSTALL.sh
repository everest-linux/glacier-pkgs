#!/bin/sh

make install PREFIX="/usr"