#!/bin/sh

rm /etc/services
rm /etc/protocols
