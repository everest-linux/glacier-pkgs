#!/bin/sh

cp services protocols /etc
