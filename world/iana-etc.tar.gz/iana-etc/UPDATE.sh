#!/bin/sh

rm /etc/services
rm /etc/protocols
cp services protocols /etc
