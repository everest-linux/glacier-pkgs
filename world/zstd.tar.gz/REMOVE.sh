#!/bin/sh

rm /bin/zstd /bin/zstdcat /bin/zstdgrep /bin/zstdless /bin/zstdmnt /bin/unzstd
rm /lib/libzstd.so
