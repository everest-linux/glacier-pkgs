#!/bin/sh

rm /bin/zstd /bin/zstdcat /bin/zstdgrep /bin/zstdless /bin/zstdmnt /bin/unzstd
rm /lib/libzstd.so
make
make check
make prefix=/usr install
rm -v /usr/lib/libzstd.a
