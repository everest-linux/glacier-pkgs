#!/bin/sh

touch /var/log/glacier/neofetch.timestamp
date >> /var/log/glacier/neofetch.timestamp
