#!/bin/sh

make install
