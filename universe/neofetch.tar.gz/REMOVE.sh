#!/bin/sh

rm /bin/neofetch
