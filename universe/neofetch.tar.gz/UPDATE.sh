#!/bin/sh

rm /bin/neofetch
make install
